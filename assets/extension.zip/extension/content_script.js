try {
var element = document.querySelector('ytd-popup-container');
element.parentElement.removeChild(element);
document.querySelectorAll('video').forEach(v => { v.play() })
console.log("success")
}
catch {
console.log("either failed or there was no popup")
}